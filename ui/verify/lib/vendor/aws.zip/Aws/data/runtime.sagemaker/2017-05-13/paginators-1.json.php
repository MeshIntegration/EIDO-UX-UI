<?php
// This file was auto-generated from sdk-root/src/data/runtime.sagemaker/2017-05-13/paginators-1.json
return [ 'pagination' => [],];
