<?php
// This file was auto-generated from sdk-root/src/data/elasticfilesystem/2015-02-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeFileSystems', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DeleteFileSystem', 'input' => [ 'FileSystemId' => 'fs-c5a1446c', ], 'errorExpectedFromService' => true, ], ],];
