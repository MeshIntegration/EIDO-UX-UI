<?php
// This file was auto-generated from sdk-root/src/data/polly/2016-06-10/paginators-1.json
return [ 'pagination' => [ 'ListSpeechSynthesisTasks' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
